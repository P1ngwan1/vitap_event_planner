// Storage abstraction with localStorage fallback to in-memory storage

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'faculty' | 'student' | 'volunteer';
  password: string;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  venue: string;
  budget: number;
  category: string;
  status: string;
  createdBy: string;
  createdAt: string;
}

export interface Task {
  id: string;
  eventId: string;
  title: string;
  description: string;
  dueDate: string;
  status: 'pending' | 'in-progress' | 'completed';
  priority: 'low' | 'medium' | 'high';
  assignedTo: string | null;
  progress: number;
}

export interface Registration {
  id: string;
  eventId: string;
  userId: string;
  registeredAt: string;
}

// In-memory storage fallback
let inMemoryStorage: Record<string, string> = {};
let useInMemory = false;

// Check if localStorage is available
function isLocalStorageAvailable(): boolean {
  try {
    const test = '__localStorage_test__';
    localStorage.setItem(test, test);
    localStorage.removeItem(test);
    return true;
  } catch (e) {
    return false;
  }
}

// Storage abstraction
const storage = {
  getItem(key: string): string | null {
    if (useInMemory || !isLocalStorageAvailable()) {
      useInMemory = true;
      return inMemoryStorage[key] || null;
    }
    try {
      return localStorage.getItem(key);
    } catch (e) {
      useInMemory = true;
      return inMemoryStorage[key] || null;
    }
  },
  
  setItem(key: string, value: string): void {
    if (useInMemory || !isLocalStorageAvailable()) {
      useInMemory = true;
      inMemoryStorage[key] = value;
      return;
    }
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      useInMemory = true;
      inMemoryStorage[key] = value;
    }
  }
};

// Initialize storage with default data
export function initializeStorage() {
  try {
    if (!storage.getItem('users')) {
      const defaultUsers: User[] = [
        {
          id: '1',
          email: 'admin@college.edu',
          name: 'Admin User',
          role: 'admin',
          password: 'admin123'
        },
        {
          id: '2',
          email: 'faculty@college.edu',
          name: 'Faculty Member',
          role: 'faculty',
          password: 'faculty123'
        },
        {
          id: '3',
          email: 'student@college.edu',
          name: 'Student User',
          role: 'student',
          password: 'student123'
        }
      ];
      storage.setItem('users', JSON.stringify(defaultUsers));
    }

    if (!storage.getItem('events')) {
      storage.setItem('events', JSON.stringify([]));
    }

    if (!storage.getItem('tasks')) {
      storage.setItem('tasks', JSON.stringify([]));
    }

    if (!storage.getItem('registrations')) {
      storage.setItem('registrations', JSON.stringify([]));
    }

    if (!storage.getItem('currentUser')) {
      storage.setItem('currentUser', '');
    }
  } catch (error) {
    console.error('Error initializing storage:', error);
  }
}

// User Management
export function signup(email: string, password: string, name: string, role: string): User {
  const users = getUsers();
  
  // Check if user exists
  if (users.find(u => u.email === email)) {
    throw new Error('User already exists');
  }

  const newUser: User = {
    id: Date.now().toString(),
    email,
    name,
    role: role as any,
    password
  };

  users.push(newUser);
  storage.setItem('users', JSON.stringify(users));
  
  return newUser;
}

export function login(email: string, password: string): User {
  const users = getUsers();
  const user = users.find(u => u.email === email && u.password === password);
  
  if (!user) {
    throw new Error('Invalid email or password');
  }

  storage.setItem('currentUser', user.id);
  return user;
}

export function logout() {
  storage.setItem('currentUser', '');
}

export function getCurrentUser(): User | null {
  try {
    const userId = storage.getItem('currentUser');
    if (!userId) return null;
    
    const users = getUsers();
    return users.find(u => u.id === userId) || null;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
}

export function getUsers(): User[] {
  try {
    const data = storage.getItem('users');
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting users:', error);
    return [];
  }
}

// Event Management
export function createEvent(event: Omit<Event, 'id' | 'createdAt'>): Event {
  const events = getEvents();
  
  const newEvent: Event = {
    ...event,
    id: Date.now().toString(),
    createdAt: new Date().toISOString()
  };

  events.push(newEvent);
  storage.setItem('events', JSON.stringify(events));
  
  return newEvent;
}

export function getEvents(): Event[] {
  try {
    const data = storage.getItem('events');
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting events:', error);
    return [];
  }
}

export function getEventById(id: string): Event | null {
  const events = getEvents();
  return events.find(e => e.id === id) || null;
}

export function updateEvent(id: string, updates: Partial<Event>): Event {
  const events = getEvents();
  const index = events.findIndex(e => e.id === id);
  
  if (index === -1) {
    throw new Error('Event not found');
  }

  events[index] = { ...events[index], ...updates };
  storage.setItem('events', JSON.stringify(events));
  
  return events[index];
}

export function deleteEvent(id: string) {
  const events = getEvents();
  const filtered = events.filter(e => e.id !== id);
  storage.setItem('events', JSON.stringify(filtered));
  
  // Also delete related tasks and registrations
  const tasks = getTasks().filter(t => t.eventId !== id);
  storage.setItem('tasks', JSON.stringify(tasks));
  
  const registrations = getRegistrations().filter(r => r.eventId !== id);
  storage.setItem('registrations', JSON.stringify(registrations));
}

// Task Management
export function createTask(task: Omit<Task, 'id'>): Task {
  const tasks = getTasks();
  
  const newTask: Task = {
    ...task,
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9)
  };

  tasks.push(newTask);
  storage.setItem('tasks', JSON.stringify(tasks));
  
  return newTask;
}

export function getTasks(): Task[] {
  try {
    const data = storage.getItem('tasks');
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting tasks:', error);
    return [];
  }
}

export function getTasksByEventId(eventId: string): Task[] {
  const tasks = getTasks();
  return tasks.filter(t => t.eventId === eventId);
}

export function updateTask(id: string, updates: Partial<Task>): Task {
  const tasks = getTasks();
  const index = tasks.findIndex(t => t.id === id);
  
  if (index === -1) {
    throw new Error('Task not found');
  }

  tasks[index] = { ...tasks[index], ...updates };
  storage.setItem('tasks', JSON.stringify(tasks));
  
  return tasks[index];
}

export function deleteTask(id: string) {
  const tasks = getTasks();
  const filtered = tasks.filter(t => t.id !== id);
  storage.setItem('tasks', JSON.stringify(filtered));
}

// Generate AI Plan (Mock)
export function generateAIPlan(eventId: string, eventDate: string, eventTitle: string): Task[] {
  const eventDateTime = new Date(eventDate);
  const tasks: Omit<Task, 'id'>[] = [];

  // Generate tasks based on event timeline
  const taskTemplates = [
    { weeks: 8, title: 'Initial Planning & Budget Approval', description: 'Define event objectives, create initial budget, and get stakeholder approval', priority: 'high' as const },
    { weeks: 7, title: 'Venue Booking & Setup Planning', description: 'Book venue, plan layout, and arrange necessary equipment', priority: 'high' as const },
    { weeks: 6, title: 'Marketing & Promotion Strategy', description: 'Create promotional materials, social media campaigns, and marketing timeline', priority: 'medium' as const },
    { weeks: 5, title: 'Speaker/Guest Coordination', description: 'Confirm speakers, guests, and special participants', priority: 'high' as const },
    { weeks: 4, title: 'Registration System Setup', description: 'Set up online registration, ticketing, and participant tracking', priority: 'medium' as const },
    { weeks: 3, title: 'Logistics & Catering Arrangement', description: 'Arrange catering, transportation, and accommodation if needed', priority: 'medium' as const },
    { weeks: 2, title: 'Volunteer Recruitment & Training', description: 'Recruit volunteers and conduct training sessions', priority: 'medium' as const },
    { weeks: 1, title: 'Final Preparations & Rehearsal', description: 'Conduct final checks, rehearsals, and confirm all arrangements', priority: 'high' as const },
    { weeks: 0, title: 'Event Day Execution', description: 'Execute event as planned and manage on-site activities', priority: 'high' as const },
    { weeks: -1, title: 'Post-Event Follow-up & Report', description: 'Send thank you messages, collect feedback, and prepare event report', priority: 'low' as const }
  ];

  taskTemplates.forEach(template => {
    const dueDate = new Date(eventDateTime);
    dueDate.setDate(dueDate.getDate() - (template.weeks * 7));
    
    tasks.push({
      eventId,
      title: template.title,
      description: template.description,
      dueDate: dueDate.toISOString(),
      status: 'pending',
      priority: template.priority,
      assignedTo: null,
      progress: 0
    });
  });

  // Create all tasks
  const createdTasks = tasks.map(task => createTask(task));
  
  return createdTasks;
}

// Registration Management
export function registerForEvent(eventId: string, userId: string): Registration {
  const registrations = getRegistrations();
  
  // Check if already registered
  if (registrations.find(r => r.eventId === eventId && r.userId === userId)) {
    throw new Error('Already registered for this event');
  }

  const newRegistration: Registration = {
    id: Date.now().toString(),
    eventId,
    userId,
    registeredAt: new Date().toISOString()
  };

  registrations.push(newRegistration);
  storage.setItem('registrations', JSON.stringify(registrations));
  
  return newRegistration;
}

export function getRegistrations(): Registration[] {
  try {
    const data = storage.getItem('registrations');
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting registrations:', error);
    return [];
  }
}

export function getRegistrationsByEventId(eventId: string): Registration[] {
  const registrations = getRegistrations();
  return registrations.filter(r => r.eventId === eventId);
}

export function isUserRegistered(eventId: string, userId: string): boolean {
  const registrations = getRegistrations();
  return registrations.some(r => r.eventId === eventId && r.userId === userId);
}

export function unregisterFromEvent(eventId: string, userId: string) {
  const registrations = getRegistrations();
  const filtered = registrations.filter(r => !(r.eventId === eventId && r.userId === userId));
  storage.setItem('registrations', JSON.stringify(filtered));
}
