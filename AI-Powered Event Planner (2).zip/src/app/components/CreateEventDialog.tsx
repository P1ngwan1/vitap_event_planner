import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { createEvent, getCurrentUser } from '../lib/storage';

interface CreateEventDialogProps {
  open: boolean;
  onClose: () => void;
  onEventCreated: () => void;
}

export function CreateEventDialog({ open, onClose, onEventCreated }: CreateEventDialogProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    venue: '',
    budget: '',
    category: 'general'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const currentUser = getCurrentUser();
      if (!currentUser) {
        throw new Error('You must be logged in to create an event');
      }

      createEvent({
        title: formData.title,
        description: formData.description,
        date: formData.date,
        venue: formData.venue,
        budget: parseFloat(formData.budget) || 0,
        category: formData.category,
        status: 'upcoming',
        createdBy: currentUser.id
      });

      toast.success('Event created successfully!');
      setFormData({
        title: '',
        description: '',
        date: '',
        venue: '',
        budget: '',
        category: 'general'
      });
      onEventCreated();
      onClose();
    } catch (error: any) {
      console.error('Create event error:', error);
      toast.error(error.message || 'Failed to create event');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-[95vw] max-w-2xl max-h-[90vh] overflow-y-auto">
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, rotateX: -20 }}
              animate={{ opacity: 1, scale: 1, rotateX: 0 }}
              exit={{ opacity: 0, scale: 0.9, rotateX: 20 }}
              transition={{ duration: 0.4 }}
              style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
            >
              <DialogHeader>
                <motion.div
                  initial={{ y: -20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.1 }}
                  style={{ transform: 'translateZ(20px)' }}
                >
                  <DialogTitle className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent text-xl sm:text-2xl">
                    Create New Event
                  </DialogTitle>
                  <DialogDescription className="text-sm sm:text-base mt-2">
                    Fill in the details to create a new college event
                  </DialogDescription>
                </motion.div>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6 mt-4 sm:mt-6">
                <motion.div 
                  className="space-y-2"
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  whileHover={{ x: 5 }}
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  <Label htmlFor="title" className="text-base">Event Title *</Label>
                  <motion.div whileFocus={{ scale: 1.02 }}>
                    <Input
                      id="title"
                      placeholder="Annual Tech Fest 2024"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                      className="border-2 focus:border-indigo-500 transition-all"
                    />
                  </motion.div>
                </motion.div>

                <motion.div 
                  className="space-y-2"
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  whileHover={{ x: 5 }}
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  <Label htmlFor="description" className="text-base">Description</Label>
                  <motion.div whileFocus={{ scale: 1.02 }}>
                    <Textarea
                      id="description"
                      placeholder="Describe your event..."
                      rows={4}
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      className="border-2 focus:border-indigo-500 transition-all resize-none"
                    />
                  </motion.div>
                </motion.div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                  <motion.div 
                    className="space-y-2"
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    whileHover={{ scale: 1.02, rotateY: 2 }}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <Label htmlFor="date" className="text-base">Date & Time *</Label>
                    <Input
                      id="date"
                      type="datetime-local"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      required
                      className="border-2 focus:border-indigo-500 transition-all"
                    />
                  </motion.div>

                  <motion.div 
                    className="space-y-2"
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    whileHover={{ scale: 1.02, rotateY: -2 }}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <Label htmlFor="category" className="text-base">Category</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                      <SelectTrigger className="border-2 focus:border-indigo-500">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General</SelectItem>
                        <SelectItem value="technical">Technical</SelectItem>
                        <SelectItem value="cultural">Cultural</SelectItem>
                        <SelectItem value="sports">Sports</SelectItem>
                        <SelectItem value="workshop">Workshop</SelectItem>
                        <SelectItem value="seminar">Seminar</SelectItem>
                      </SelectContent>
                    </Select>
                  </motion.div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                  <motion.div 
                    className="space-y-2"
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.6 }}
                    whileHover={{ scale: 1.02, rotateY: 2 }}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <Label htmlFor="venue" className="text-base">Venue</Label>
                    <Input
                      id="venue"
                      placeholder="Main Auditorium"
                      value={formData.venue}
                      onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                      className="border-2 focus:border-indigo-500 transition-all"
                    />
                  </motion.div>

                  <motion.div 
                    className="space-y-2"
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.7 }}
                    whileHover={{ scale: 1.02, rotateY: -2 }}
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <Label htmlFor="budget" className="text-base">Budget ($)</Label>
                    <Input
                      id="budget"
                      type="number"
                      placeholder="5000"
                      value={formData.budget}
                      onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                      className="border-2 focus:border-indigo-500 transition-all"
                    />
                  </motion.div>
                </div>

                <motion.div 
                  className="flex flex-col sm:flex-row gap-3 pt-4 border-t"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.8 }}
                >
                  <motion.div
                    whileHover={{ scale: 1.05, rotateY: -5 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex-1 sm:flex-initial"
                  >
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={onClose} 
                      disabled={isLoading}
                      className="w-full sm:w-auto border-2 hover:border-gray-400"
                    >
                      Cancel
                    </Button>
                  </motion.div>
                  <motion.div
                    whileHover={{ scale: 1.05, rotateY: 5 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex-1"
                  >
                    <Button 
                      type="submit" 
                      disabled={isLoading} 
                      className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-lg"
                    >
                      {isLoading ? (
                        <motion.span
                          animate={{ opacity: [0.5, 1, 0.5] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                        >
                          Creating...
                        </motion.span>
                      ) : (
                        'Create Event'
                      )}
                    </Button>
                  </motion.div>
                </motion.div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}