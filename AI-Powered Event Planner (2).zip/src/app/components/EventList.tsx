import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Calendar, MapPin, Users, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'motion/react';
import { getEvents, getRegistrationsByEventId, Event } from '../lib/storage';

interface EventListProps {
  onEventSelect: (eventId: string) => void;
  onCreateEvent: () => void;
  userRole: string;
}

export function EventList({ onEventSelect, onCreateEvent, userRole }: EventListProps) {
  const [events, setEvents] = useState<Event[]>([]);
  const [registrationCounts, setRegistrationCounts] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'past'>('all');
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = () => {
    try {
      setLoading(true);
      const allEvents = getEvents();
      setEvents(allEvents);
      
      // Get registration counts for all events
      const counts: Record<string, number> = {};
      allEvents.forEach(event => {
        counts[event.id] = getRegistrationsByEventId(event.id).length;
      });
      setRegistrationCounts(counts);
    } catch (error: any) {
      console.error('Failed to fetch events:', error);
      toast.error('Failed to load events');
    } finally {
      setLoading(false);
    }
  };

  const filteredEvents = events.filter(event => {
    if (filter === 'all') return true;
    const eventDate = new Date(event.date);
    const today = new Date();
    if (filter === 'upcoming') return eventDate >= today;
    if (filter === 'past') return eventDate < today;
    return true;
  });

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      general: 'bg-gray-500',
      technical: 'bg-blue-500',
      cultural: 'bg-purple-500',
      sports: 'bg-green-500',
      workshop: 'bg-orange-500',
      seminar: 'bg-indigo-500'
    };
    return colors[category] || 'bg-gray-500';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div 
            className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full mx-auto"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
          <motion.p 
            className="mt-4 text-gray-600"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            Loading events...
          </motion.p>
        </motion.div>
      </div>
    );
  }

  return (
    <motion.div 
      className="space-y-4 sm:space-y-6 w-full"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
    >
      {/* Header Section with 3D effects */}
      <motion.div 
        className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4"
        initial={{ y: -20, opacity: 0, rotateX: -20 }}
        animate={{ y: 0, opacity: 1, rotateX: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        style={{ perspective: '1000px', transformStyle: 'preserve-3d' }}
      >
        <div className="w-full sm:w-auto">
          <motion.h2 
            className="text-xl sm:text-2xl lg:text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent"
            whileHover={{ scale: 1.05 }}
            style={{ transform: 'translateZ(20px)' }}
          >
            Events
          </motion.h2>
          <motion.p 
            className="text-sm sm:text-base text-gray-600 mt-1"
            style={{ transform: 'translateZ(10px)' }}
          >
            Browse and manage college events
          </motion.p>
        </div>
        
        {(userRole === 'admin' || userRole === 'faculty') && (
          <motion.div
            whileHover={{ scale: 1.08, rotateY: 5 }}
            whileTap={{ scale: 0.95 }}
            style={{ transformStyle: 'preserve-3d' }}
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Button 
              onClick={onCreateEvent}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl transition-all w-full sm:w-auto"
            >
              Create New Event
            </Button>
          </motion.div>
        )}
      </motion.div>

      {/* Filter Pills with 3D effects */}
      <motion.div 
        className="flex flex-wrap gap-2 sm:gap-3"
        initial={{ y: -10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        {(['all', 'upcoming', 'past'] as const).map((f, index) => (
          <motion.div
            key={f}
            whileHover={{ scale: 1.1, y: -3 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 + index * 0.1 }}
          >
            <Badge
              onClick={() => setFilter(f)}
              className={`cursor-pointer px-4 py-2 text-sm sm:text-base transition-all ${
                filter === f 
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg' 
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-300'
              }`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </Badge>
          </motion.div>
        ))}
      </motion.div>

      {/* Events Grid with 3D cards */}
      {filteredEvents.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="border-2 border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <motion.div
                animate={{ 
                  rotate: [0, 10, -10, 0],
                  scale: [1, 1.1, 1]
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Calendar className="w-16 h-16 text-gray-400 mb-4" />
              </motion.div>
              <p className="text-gray-500 text-center">No events found</p>
              {(userRole === 'admin' || userRole === 'faculty') && (
                <Button onClick={onCreateEvent} className="mt-4">
                  Create Your First Event
                </Button>
              )}
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          {filteredEvents.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 50, rotateX: -20 }}
              animate={{ opacity: 1, y: 0, rotateX: 0 }}
              transition={{ 
                delay: 0.7 + index * 0.1,
                duration: 0.5,
                type: "spring"
              }}
              whileHover={{ 
                scale: 1.05,
                rotateY: hoveredCard === event.id ? 5 : 0,
                z: 50,
                transition: { duration: 0.3 }
              }}
              style={{ 
                perspective: '1500px',
                transformStyle: 'preserve-3d'
              }}
              onHoverStart={() => setHoveredCard(event.id)}
              onHoverEnd={() => setHoveredCard(null)}
            >
              <Card 
                className="cursor-pointer overflow-hidden border-2 hover:border-indigo-300 transition-all duration-300 h-full relative group"
                onClick={() => onEventSelect(event.id)}
                style={{
                  transformStyle: 'preserve-3d',
                  boxShadow: hoveredCard === event.id 
                    ? '0 25px 50px -12px rgba(99, 102, 241, 0.25)' 
                    : '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
                }}
              >
                {/* Animated gradient overlay */}
                <motion.div
                  className="absolute inset-0 opacity-0 group-hover:opacity-10 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 pointer-events-none"
                  animate={hoveredCard === event.id ? {
                    scale: [1, 1.2, 1],
                    rotate: [0, 90, 0],
                  } : {}}
                  transition={{ duration: 3, repeat: Infinity }}
                />
                
                <CardHeader style={{ transform: 'translateZ(30px)' }}>
                  <div className="flex justify-between items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <motion.div
                        style={{ transform: 'translateZ(40px)' }}
                      >
                        <CardTitle className="text-lg sm:text-xl truncate bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                          {event.title}
                        </CardTitle>
                      </motion.div>
                      <motion.div
                        style={{ transform: 'translateZ(30px)' }}
                      >
                        <CardDescription className="mt-2 line-clamp-2">
                          {event.description || 'No description'}
                        </CardDescription>
                      </motion.div>
                    </div>
                    <motion.div
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.5 }}
                      style={{ transform: 'translateZ(50px)' }}
                    >
                      <Badge className={getCategoryColor(event.category)}>
                        {event.category}
                      </Badge>
                    </motion.div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3" style={{ transform: 'translateZ(20px)' }}>
                  <motion.div 
                    className="flex items-center gap-2 text-sm text-gray-600"
                    whileHover={{ x: 5 }}
                    style={{ transform: 'translateZ(25px)' }}
                  >
                    <Calendar className="w-4 h-4 text-indigo-500" />
                    <span className="truncate">
                      {new Date(event.date).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </motion.div>
                  
                  {event.venue && (
                    <motion.div 
                      className="flex items-center gap-2 text-sm text-gray-600"
                      whileHover={{ x: 5 }}
                      style={{ transform: 'translateZ(25px)' }}
                    >
                      <MapPin className="w-4 h-4 text-indigo-500" />
                      <span className="truncate">{event.venue}</span>
                    </motion.div>
                  )}
                  
                  <div className="flex items-center justify-between pt-2 border-t">
                    <motion.div 
                      className="flex items-center gap-2 text-sm text-gray-600"
                      whileHover={{ scale: 1.1 }}
                      style={{ transform: 'translateZ(30px)' }}
                    >
                      <Users className="w-4 h-4 text-indigo-500" />
                      <span>{registrationCounts[event.id] || 0} registered</span>
                    </motion.div>
                    
                    <motion.div
                      whileHover={{ x: 5 }}
                      style={{ transform: 'translateZ(30px)' }}
                    >
                      <ChevronRight className="w-5 h-5 text-indigo-600" />
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}
    </motion.div>
  );
}