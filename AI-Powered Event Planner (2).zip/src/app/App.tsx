import { useEffect, useState } from 'react';
import { LogOut, User } from 'lucide-react';
import { motion } from 'motion/react';

import { initializeStorage, getCurrentUser, logout, User as UserType } from './lib/storage';

import { AuthForm } from './components/AuthForm';
import { EventList } from './components/EventList';
import { EventDetails } from './components/EventDetails';
import { CreateEventDialog } from './components/CreateEventDialog';

import { Button } from './components/ui/button';
import { Toaster } from './components/ui/sonner';

/* ---------------- Types ---------------- */

type View = 'list' | 'details';

/* ---------------- App ---------------- */

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<UserType | null>(null);
  const [currentView, setCurrentView] = useState<View>('list');
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  /* -------- Check existing session -------- */

  useEffect(() => {
    try {
      // Initialize localStorage on first load
      initializeStorage();
      
      // Check if user is logged in
      const currentUser = getCurrentUser();
      if (currentUser) {
        setUser(currentUser);
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.error('Error initializing app:', error);
    }
  }, []);

  /* -------- Auth Success -------- */

  const handleAuthSuccess = (authUser: UserType) => {
    setUser(authUser);
    setIsAuthenticated(true);
  };

  /* -------- Logout -------- */

  const handleLogout = () => {
    logout();
    setIsAuthenticated(false);
    setUser(null);
    setCurrentView('list');
    setSelectedEventId(null);
  };

  /* -------- Navigation -------- */

  const handleEventSelect = (eventId: string) => {
    setSelectedEventId(eventId);
    setCurrentView('details');
  };

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedEventId(null);
  };

  const handleCreateEvent = () => {
    setShowCreateDialog(true);
  };

  const handleEventCreated = () => {
    setShowCreateDialog(false);
    setCurrentView('list');
  };

  /* -------- Auth Screen -------- */

  if (!isAuthenticated) {
    return (
      <>
        <AuthForm onAuthSuccess={handleAuthSuccess} />
        <Toaster />
      </>
    );
  }

  /* -------- Main UI -------- */

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 relative overflow-x-hidden">
      {/* Animated Background */}
      <motion.div
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{ perspective: '1000px' }}
      >
        <motion.div
          className="absolute top-[10%] left-[5%] w-48 h-48 sm:w-72 sm:h-72 lg:w-96 lg:h-96 bg-indigo-400 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{ duration: 20, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-[10%] right-[5%] w-40 h-40 sm:w-60 sm:h-60 lg:w-80 lg:h-80 bg-cyan-400 rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
          }}
          transition={{ duration: 25, repeat: Infinity }}
        />
      </motion.div>

      {/* Header */}
      <header className="relative bg-white/80 backdrop-blur-xl shadow-xl border-b w-full">
        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
          <div className="flex-1 min-w-0">
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent truncate">
              College Event Planner
            </h1>
            <p className="text-xs sm:text-sm text-gray-600 mt-0.5">
              AI-Powered Event Management
            </p>
          </div>

          <div className="flex items-center gap-2 sm:gap-4 w-full sm:w-auto">
            <div className="flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-indigo-50 rounded-xl flex-1 sm:flex-initial">
              <User className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-600 flex-shrink-0" />
              <div className="text-xs sm:text-sm min-w-0">
                <p className="font-medium truncate">{user?.name}</p>
                <p className="text-[10px] sm:text-xs text-gray-600 capitalize">
                  {user?.role}
                </p>
              </div>
            </div>

            <Button
              variant="ghost"
              onClick={handleLogout}
              className="hover:bg-red-50 hover:text-red-600 px-2 sm:px-4 flex-shrink-0"
              size="sm"
            >
              <LogOut className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-2" />
              <span className="hidden sm:inline">Logout</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-10">
        {currentView === 'list' && (
          <EventList
            onEventSelect={handleEventSelect}
            onCreateEvent={handleCreateEvent}
            userRole={user?.role ?? 'student'}
          />
        )}

        {currentView === 'details' && selectedEventId && user && (
          <EventDetails
            eventId={selectedEventId}
            userId={user.id}
            userRole={user.role}
            onBack={handleBackToList}
          />
        )}
      </main>

      {/* Create Event Dialog */}
      <CreateEventDialog
        open={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        onEventCreated={handleEventCreated}
      />

      <Toaster />
    </div>
  );
}