// Local file-system based key-value store (replaces Supabase)
// Data is stored as JSON files on your local system

const DATA_DIR = "./local_db";

// Ensure data directory exists
async function ensureDir() {
  try {
    await Deno.mkdir(DATA_DIR, { recursive: true });
  } catch {
    // Directory already exists
  }
}

function keyToFilePath(key: string): string {
  // Sanitize key to use as filename
  const safeKey = key.replace(/[^a-zA-Z0-9_\-]/g, "_");
  return `${DATA_DIR}/${safeKey}.json`;
}

// Set stores a key-value pair as a JSON file on disk.
export const set = async (key: string, value: any): Promise<void> => {
  await ensureDir();
  const filePath = keyToFilePath(key);
  await Deno.writeTextFile(filePath, JSON.stringify({ key, value }));
};

// Get retrieves a key-value pair from disk.
export const get = async (key: string): Promise<any> => {
  await ensureDir();
  const filePath = keyToFilePath(key);
  try {
    const content = await Deno.readTextFile(filePath);
    const parsed = JSON.parse(content);
    return parsed.value;
  } catch {
    return null;
  }
};

// Delete deletes a key-value pair from disk.
export const del = async (key: string): Promise<void> => {
  const filePath = keyToFilePath(key);
  try {
    await Deno.remove(filePath);
  } catch {
    // File doesn't exist, ignore
  }
};

// Sets multiple key-value pairs.
export const mset = async (keys: string[], values: any[]): Promise<void> => {
  await Promise.all(keys.map((k, i) => set(k, values[i])));
};

// Gets multiple key-value pairs.
export const mget = async (keys: string[]): Promise<any[]> => {
  return Promise.all(keys.map((k) => get(k)));
};

// Deletes multiple key-value pairs.
export const mdel = async (keys: string[]): Promise<void> => {
  await Promise.all(keys.map((k) => del(k)));
};

// Search for key-value pairs by prefix (scans local_db directory).
export const getByPrefix = async (prefix: string): Promise<any[]> => {
  await ensureDir();
  const results: any[] = [];
  try {
    for await (const entry of Deno.readDir(DATA_DIR)) {
      if (entry.isFile && entry.name.endsWith(".json")) {
        try {
          const content = await Deno.readTextFile(`${DATA_DIR}/${entry.name}`);
          const parsed = JSON.parse(content);
          if (parsed.key && parsed.key.startsWith(prefix)) {
            results.push({ key: parsed.key, value: parsed.value });
          }
        } catch {
          // Skip malformed files
        }
      }
    }
  } catch {
    // Directory read error
  }
  return results;
};
