import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

// ─── LOCAL AUTH (no Supabase) ───────────────────────────────────────────────
// Users are stored as JSON files on disk via kv_store.
// Sessions are simple token strings stored server-side in kv_store.

const app = new Hono();

app.use("*", logger(console.log));
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// ── Health ──────────────────────────────────────────────────────────────────
app.get("/make-server-ab090f4e/health", (c) => {
  return c.json({ status: "ok", storage: "local-filesystem" });
});

// ── Helper: get authenticated user from token ────────────────────────────────
async function getAuthUser(token: string | undefined) {
  if (!token) return null;
  const session = await kv.get(`session:${token}`);
  if (!session) return null;
  const user = await kv.get(`user:${session.userId}`);
  return user || null;
}

// ── SIGN UP ──────────────────────────────────────────────────────────────────
app.post("/make-server-ab090f4e/signup", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, name, role = "student" } = body;

    if (!email || !password || !name) {
      return c.json({ error: "Email, password, and name are required" }, 400);
    }

    const validRoles = ["admin", "faculty", "student", "volunteer"];
    if (!validRoles.includes(role)) {
      return c.json({ error: "Invalid role" }, 400);
    }

    // Check duplicate
    const existing = await kv.get(`user_email:${email}`);
    if (existing) {
      return c.json({ error: "User already exists with this email" }, 400);
    }

    const userId = `user_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    const user = { id: userId, email, password, name, role };

    await kv.set(`user:${userId}`, user);
    await kv.set(`user_email:${email}`, userId); // email → id index

    console.log(`User created: ${email} (${role})`);
    return c.json({ message: "User created successfully", user: { id: userId, email, name, role } });
  } catch (error) {
    console.log(`Signup error: ${error}`);
    return c.json({ error: "Failed to create user" }, 500);
  }
});

// ── LOGIN ─────────────────────────────────────────────────────────────────────
app.post("/make-server-ab090f4e/login", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password } = body;

    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }

    const userId = await kv.get(`user_email:${email}`);
    if (!userId) return c.json({ error: "Invalid email or password" }, 401);

    const user = await kv.get(`user:${userId}`);
    if (!user || user.password !== password) {
      return c.json({ error: "Invalid email or password" }, 401);
    }

    // Create session token
    const token = `tok_${Date.now()}_${Math.random().toString(36).substring(2)}`;
    await kv.set(`session:${token}`, { userId: user.id, createdAt: new Date().toISOString() });

    const { password: _pw, ...safeUser } = user;
    console.log(`User logged in: ${email}`);
    return c.json({ token, user: safeUser });
  } catch (error) {
    console.log(`Login error: ${error}`);
    return c.json({ error: "Failed to login" }, 500);
  }
});

// ── LOGOUT ────────────────────────────────────────────────────────────────────
app.post("/make-server-ab090f4e/logout", async (c) => {
  const token = c.req.header("Authorization")?.split(" ")[1];
  if (token) await kv.del(`session:${token}`);
  return c.json({ message: "Logged out successfully" });
});

// ── CREATE EVENT ──────────────────────────────────────────────────────────────
app.post("/make-server-ab090f4e/events", async (c) => {
  try {
    const token = c.req.header("Authorization")?.split(" ")[1];
    const user = await getAuthUser(token);
    if (!user) return c.json({ error: "Unauthorized" }, 401);

    const body = await c.req.json();
    const { title, description, date, venue, budget, category } = body;

    if (!title || !date) {
      return c.json({ error: "Title and date are required" }, 400);
    }

    const eventId = `event_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    const event = {
      id: eventId,
      title,
      description: description || "",
      date,
      venue: venue || "",
      budget: budget || 0,
      category: category || "general",
      createdBy: user.id,
      createdAt: new Date().toISOString(),
      status: "upcoming",
    };

    await kv.set(`event:${eventId}`, event);

    // Track user's created events
    const userEvents = (await kv.get(`user:${user.id}:created_events`)) || [];
    userEvents.push(eventId);
    await kv.set(`user:${user.id}:created_events`, userEvents);

    console.log(`Event created: ${eventId} by ${user.id}`);
    return c.json({ event });
  } catch (error) {
    console.log(`Event creation error: ${error}`);
    return c.json({ error: "Failed to create event" }, 500);
  }
});

// ── GET ALL EVENTS ─────────────────────────────────────────────────────────────
app.get("/make-server-ab090f4e/events", async (c) => {
  try {
    const items = await kv.getByPrefix("event:");
    const events = items
      .filter((item) => !item.key.includes(":tasks") && !item.key.includes(":registrations"))
      .map((item) => item.value);
    return c.json({ events });
  } catch (error) {
    console.log(`Get events error: ${error}`);
    return c.json({ error: "Failed to fetch events" }, 500);
  }
});

// ── GET SINGLE EVENT ──────────────────────────────────────────────────────────
app.get("/make-server-ab090f4e/events/:id", async (c) => {
  try {
    const eventId = c.req.param("id");
    const event = await kv.get(`event:${eventId}`);
    if (!event) return c.json({ error: "Event not found" }, 404);

    const tasks = (await kv.get(`event:${eventId}:tasks`)) || [];
    const registrations = (await kv.get(`event:${eventId}:registrations`)) || [];

    return c.json({ event, tasks, registrations: registrations.length });
  } catch (error) {
    console.log(`Get event error: ${error}`);
    return c.json({ error: "Failed to fetch event" }, 500);
  }
});

// ── REGISTER FOR EVENT ─────────────────────────────────────────────────────────
app.post("/make-server-ab090f4e/events/:id/register", async (c) => {
  try {
    const token = c.req.header("Authorization")?.split(" ")[1];
    const user = await getAuthUser(token);
    if (!user) return c.json({ error: "Unauthorized" }, 401);

    const eventId = c.req.param("id");
    const event = await kv.get(`event:${eventId}`);
    if (!event) return c.json({ error: "Event not found" }, 404);

    const registrations = (await kv.get(`event:${eventId}:registrations`)) || [];
    if (registrations.some((r: any) => r.userId === user.id)) {
      return c.json({ error: "Already registered for this event" }, 400);
    }

    const registration = {
      userId: user.id,
      eventId,
      registeredAt: new Date().toISOString(),
      attended: false,
    };

    registrations.push(registration);
    await kv.set(`event:${eventId}:registrations`, registrations);

    const userRegs = (await kv.get(`user:${user.id}:registrations`)) || [];
    userRegs.push(eventId);
    await kv.set(`user:${user.id}:registrations`, userRegs);

    return c.json({ message: "Successfully registered", registration });
  } catch (error) {
    console.log(`Registration error: ${error}`);
    return c.json({ error: "Failed to register" }, 500);
  }
});

// ── CHECK REGISTRATION ─────────────────────────────────────────────────────────
app.get("/make-server-ab090f4e/events/:id/check-registration", async (c) => {
  try {
    const token = c.req.header("Authorization")?.split(" ")[1];
    const user = await getAuthUser(token);
    if (!user) return c.json({ error: "Unauthorized" }, 401);

    const eventId = c.req.param("id");
    const registrations = (await kv.get(`event:${eventId}:registrations`)) || [];
    const isRegistered = registrations.some((reg: any) => reg.userId === user.id);

    return c.json({ isRegistered });
  } catch (error) {
    return c.json({ error: "Failed to check registration" }, 500);
  }
});

// ── GENERATE AI PLAN ──────────────────────────────────────────────────────────
app.post("/make-server-ab090f4e/events/:id/generate-plan", async (c) => {
  try {
    const token = c.req.header("Authorization")?.split(" ")[1];
    const user = await getAuthUser(token);
    if (!user) return c.json({ error: "Unauthorized" }, 401);

    const eventId = c.req.param("id");
    const event = await kv.get(`event:${eventId}`);
    if (!event) return c.json({ error: "Event not found" }, 404);

    const eventDate = new Date(event.date);
    const today = new Date();
    const daysUntilEvent = Math.max(
      1,
      Math.floor((eventDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)),
    );

    const offset = (d: number) =>
      new Date(today.getTime() + d * 24 * 60 * 60 * 1000).toISOString();

    const tasks = [
      { id: `task_${Date.now()}_1`, title: "Venue Booking Confirmation", description: "Confirm venue availability and finalize booking", dueDate: offset(Math.min(7, daysUntilEvent - 1)), status: "pending", priority: "high", assignedTo: null },
      { id: `task_${Date.now()}_2`, title: "Budget Allocation", description: "Allocate budget for different event segments", dueDate: offset(Math.min(10, daysUntilEvent - 1)), status: "pending", priority: "high", assignedTo: null },
      { id: `task_${Date.now()}_3`, title: "Marketing & Promotion", description: "Create promotional materials and distribute", dueDate: offset(Math.min(14, daysUntilEvent - 1)), status: "pending", priority: "medium", assignedTo: null },
      { id: `task_${Date.now()}_4`, title: "Speaker/Guest Coordination", description: "Contact and confirm speakers or special guests", dueDate: offset(Math.min(20, daysUntilEvent - 1)), status: "pending", priority: "high", assignedTo: null },
      { id: `task_${Date.now()}_5`, title: "Equipment & Setup Arrangement", description: "Arrange audio/visual equipment and seating", dueDate: offset(Math.max(1, daysUntilEvent - 3)), status: "pending", priority: "medium", assignedTo: null },
      { id: `task_${Date.now()}_6`, title: "Catering Arrangements", description: "Finalize menu and catering service", dueDate: offset(Math.max(1, daysUntilEvent - 7)), status: "pending", priority: "medium", assignedTo: null },
      { id: `task_${Date.now()}_7`, title: "Volunteer Coordination", description: "Recruit and brief volunteers for event day", dueDate: offset(Math.max(1, daysUntilEvent - 5)), status: "pending", priority: "medium", assignedTo: null },
      { id: `task_${Date.now()}_8`, title: "Final Rehearsal", description: "Conduct final run-through of event", dueDate: offset(Math.max(1, daysUntilEvent - 1)), status: "pending", priority: "high", assignedTo: null },
    ];

    await kv.set(`event:${eventId}:tasks`, tasks);

    return c.json({ tasks, message: "Event plan generated successfully" });
  } catch (error) {
    return c.json({ error: "Failed to generate plan" }, 500);
  }
});

// ── ASSIGN TASK ────────────────────────────────────────────────────────────────
app.post("/make-server-ab090f4e/tasks/:taskId/assign", async (c) => {
  try {
    const token = c.req.header("Authorization")?.split(" ")[1];
    const user = await getAuthUser(token);
    if (!user) return c.json({ error: "Unauthorized" }, 401);

    const body = await c.req.json();
    const { eventId, userId } = body;
    const taskId = c.req.param("taskId");

    if (!eventId || !userId) return c.json({ error: "Event ID and User ID are required" }, 400);

    const tasks = (await kv.get(`event:${eventId}:tasks`)) || [];
    const taskIndex = tasks.findIndex((t: any) => t.id === taskId);
    if (taskIndex === -1) return c.json({ error: "Task not found" }, 404);

    tasks[taskIndex].assignedTo = userId;
    await kv.set(`event:${eventId}:tasks`, tasks);

    return c.json({ task: tasks[taskIndex] });
  } catch (error) {
    return c.json({ error: "Failed to assign task" }, 500);
  }
});

// ── UPDATE TASK STATUS ─────────────────────────────────────────────────────────
app.put("/make-server-ab090f4e/tasks/:taskId", async (c) => {
  try {
    const token = c.req.header("Authorization")?.split(" ")[1];
    const user = await getAuthUser(token);
    if (!user) return c.json({ error: "Unauthorized" }, 401);

    const body = await c.req.json();
    const { eventId, status, progress } = body;
    const taskId = c.req.param("taskId");

    if (!eventId) return c.json({ error: "Event ID is required" }, 400);

    const tasks = (await kv.get(`event:${eventId}:tasks`)) || [];
    const taskIndex = tasks.findIndex((t: any) => t.id === taskId);
    if (taskIndex === -1) return c.json({ error: "Task not found" }, 404);

    if (status) tasks[taskIndex].status = status;
    if (progress !== undefined) tasks[taskIndex].progress = progress;
    tasks[taskIndex].updatedAt = new Date().toISOString();

    await kv.set(`event:${eventId}:tasks`, tasks);

    return c.json({ task: tasks[taskIndex] });
  } catch (error) {
    return c.json({ error: "Failed to update task" }, 500);
  }
});

// ── MARK ATTENDANCE ────────────────────────────────────────────────────────────
app.post("/make-server-ab090f4e/events/:id/attendance", async (c) => {
  try {
    const token = c.req.header("Authorization")?.split(" ")[1];
    const user = await getAuthUser(token);
    if (!user) return c.json({ error: "Unauthorized" }, 401);

    const eventId = c.req.param("id");
    const body = await c.req.json();
    const { userId } = body;

    if (!userId) return c.json({ error: "User ID is required" }, 400);

    const registrations = (await kv.get(`event:${eventId}:registrations`)) || [];
    const regIndex = registrations.findIndex((r: any) => r.userId === userId);
    if (regIndex === -1) return c.json({ error: "User not registered for this event" }, 404);

    registrations[regIndex].attended = true;
    registrations[regIndex].attendedAt = new Date().toISOString();
    await kv.set(`event:${eventId}:registrations`, registrations);

    return c.json({ message: "Attendance marked", registration: registrations[regIndex] });
  } catch (error) {
    return c.json({ error: "Failed to mark attendance" }, 500);
  }
});

// ── GET PROFILE ────────────────────────────────────────────────────────────────
app.get("/make-server-ab090f4e/profile", async (c) => {
  try {
    const token = c.req.header("Authorization")?.split(" ")[1];
    const user = await getAuthUser(token);
    if (!user) return c.json({ error: "Unauthorized" }, 401);

    const createdEvents = (await kv.get(`user:${user.id}:created_events`)) || [];
    const registrations = (await kv.get(`user:${user.id}:registrations`)) || [];

    const { password: _pw, ...safeUser } = user;
    return c.json({ user: safeUser, createdEvents, registrations });
  } catch (error) {
    return c.json({ error: "Failed to fetch profile" }, 500);
  }
});

Deno.serve(app.fetch);
